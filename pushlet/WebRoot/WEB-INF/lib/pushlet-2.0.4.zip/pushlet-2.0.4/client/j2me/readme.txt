$Id: readme.txt,v 1.2 2005/05/19 11:23:24 justb Exp $

Below is a J2ME (Java 2 Mobile Edition) implementation for a Pushlet
client. It has been successfully run on a MIDP-2-enabled mobile phone (Nokia 6600).

Possibly it will work on a MIDP-1 phone though that has not been tested yet.

You will find an example
in the file src/nl/justobjects/pushlet/j2me/PushletMIDlet.java
