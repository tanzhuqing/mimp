Using Pushlets in Flash is easy and quite natural.

This is a very basic example. What would be handy is
a Pushlet actionscript library.

Specifics:
- pull mode only (looks like Flash cannot stream when using XML.load)
- strict XML, i.e. complete document is received with one or more Pushlet events

The working .swf is under webapps/pushlet/examples/flash
